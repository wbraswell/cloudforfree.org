-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: localhost    Database: cloudforfree_org
-- ------------------------------------------------------
-- Server version	5.7.16-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(74) NOT NULL,
  `email` varchar(200) NOT NULL,
  `github_nickname` text NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `surname` varchar(50) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `display_email` varchar(200) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `profile_pic` varchar(100) DEFAULT NULL,
  `bio` text,
  `location` varchar(100) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `admin_notes` text,
  `discussion` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `forgot_password` tinyint(4) DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  KEY `user_idx_discussion` (`discussion`),
  CONSTRAINT `user_fk_discussion` FOREIGN KEY (`discussion`) REFERENCES `discussion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_running`
--

DROP TABLE IF EXISTS `job_running`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_running` (
  `screen_pid` int(11) NOT NULL,
  `shiny_uid` int(11) NOT NULL,
  `screen_session` text NOT NULL,
  `screen_logfile` text NOT NULL,
  `compute_nodes` text NOT NULL,
  `command` text NOT NULL,
  `command_pid` int(11) NOT NULL,
  `output_line` int(11) NOT NULL,
  `output_character` int(11) NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`screen_pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access`
--

DROP TABLE IF EXISTS `access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access`
--

LOCK TABLES `access` WRITE;
/*!40000 ALTER TABLE `access` DISABLE KEYS */;
INSERT INTO `access` VALUES (1,'Member','2016-11-05 01:19:24');
/*!40000 ALTER TABLE `access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autoresponder`
--

DROP TABLE IF EXISTS `autoresponder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autoresponder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `mailing_list` int(11) DEFAULT NULL,
  `has_captcha` tinyint(4) DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autoresponder`
--

LOCK TABLES `autoresponder` WRITE;
/*!40000 ALTER TABLE `autoresponder` DISABLE KEYS */;
INSERT INTO `autoresponder` VALUES (1,'Example autoresponder','example',NULL,NULL,0,'2016-11-05 01:21:42');
/*!40000 ALTER TABLE `autoresponder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autoresponder_email`
--

DROP TABLE IF EXISTS `autoresponder_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autoresponder_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `autoresponder` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `template` int(11) NOT NULL,
  `delay` int(11) NOT NULL,
  `plaintext` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `autoresponder_email_idx_autoresponder` (`autoresponder`),
  KEY `autoresponder_email_idx_template` (`template`),
  CONSTRAINT `autoresponder_email_fk_autoresponder` FOREIGN KEY (`autoresponder`) REFERENCES `autoresponder` (`id`),
  CONSTRAINT `autoresponder_email_fk_template` FOREIGN KEY (`template`) REFERENCES `newsletter_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autoresponder_email`
--

LOCK TABLES `autoresponder_email` WRITE;
/*!40000 ALTER TABLE `autoresponder_email` DISABLE KEYS */;
INSERT INTO `autoresponder_email` VALUES (1,1,'This is an autoresponse email',1,0,'This is the plain text body of the autoresponse email.\n','2016-11-05 01:21:42');
/*!40000 ALTER TABLE `autoresponder_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autoresponder_email_element`
--

DROP TABLE IF EXISTS `autoresponder_email_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autoresponder_email_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `autoresponder_email_element_idx_email` (`email`),
  CONSTRAINT `autoresponder_email_element_fk_email` FOREIGN KEY (`email`) REFERENCES `autoresponder_email` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autoresponder_email_element`
--

LOCK TABLES `autoresponder_email_element` WRITE;
/*!40000 ALTER TABLE `autoresponder_email_element` DISABLE KEYS */;
INSERT INTO `autoresponder_email_element` VALUES (1,1,'body','HTML','<p>\n	This is the HTML body of the autoresponse email.\n</p>\n','2016-11-05 01:21:42');
/*!40000 ALTER TABLE `autoresponder_email_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket`
--

DROP TABLE IF EXISTS `basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` char(72) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `basket_idx_session` (`session`),
  KEY `basket_idx_user` (`user`),
  CONSTRAINT `basket_fk_session` FOREIGN KEY (`session`) REFERENCES `session` (`id`),
  CONSTRAINT `basket_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket`
--

LOCK TABLES `basket` WRITE;
/*!40000 ALTER TABLE `basket` DISABLE KEYS */;
/*!40000 ALTER TABLE `basket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_item`
--

DROP TABLE IF EXISTS `basket_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basket` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `unit_price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `basket_item_idx_basket` (`basket`),
  KEY `basket_item_idx_item` (`item`),
  CONSTRAINT `basket_item_fk_basket` FOREIGN KEY (`basket`) REFERENCES `basket` (`id`),
  CONSTRAINT `basket_item_fk_item` FOREIGN KEY (`item`) REFERENCES `shop_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_item`
--

LOCK TABLES `basket_item` WRITE;
/*!40000 ALTER TABLE `basket_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `basket_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_item_attribute`
--

DROP TABLE IF EXISTS `basket_item_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basket_item_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `basket_item_attribute_idx_item` (`item`),
  CONSTRAINT `basket_item_attribute_fk_item` FOREIGN KEY (`item`) REFERENCES `basket_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_item_attribute`
--

LOCK TABLES `basket_item_attribute` WRITE;
/*!40000 ALTER TABLE `basket_item_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `basket_item_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (1,'','2016-11-05 01:18:20'),(2,'Little Blogger','2016-11-05 01:20:21');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `url_title` varchar(120) NOT NULL,
  `body` text NOT NULL,
  `author` int(11) DEFAULT NULL,
  `blog` int(11) NOT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discussion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_post_idx_author` (`author`),
  KEY `blog_post_idx_blog` (`blog`),
  KEY `blog_post_idx_discussion` (`discussion`),
  CONSTRAINT `blog_post_fk_author` FOREIGN KEY (`author`) REFERENCES `user` (`id`),
  CONSTRAINT `blog_post_fk_blog` FOREIGN KEY (`blog`) REFERENCES `blog` (`id`),
  CONSTRAINT `blog_post_fk_discussion` FOREIGN KEY (`discussion`) REFERENCES `discussion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_post`
--

LOCK TABLES `blog_post` WRITE;
/*!40000 ALTER TABLE `blog_post` DISABLE KEYS */;
INSERT INTO `blog_post` VALUES (1,'First Post!','first_post','<p>I&#39;m building the new CloudForFree user interface.</p>\r\n\r\n<p>Exciting! &nbsp;:-)</p>\r\n',1,2,0,'2016-11-05 05:00:00',1);
/*!40000 ALTER TABLE `blog_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_form`
--

DROP TABLE IF EXISTS `cms_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `redirect` varchar(200) DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `email_to` varchar(100) DEFAULT NULL,
  `template` varchar(100) DEFAULT NULL,
  `has_captcha` tinyint(4) DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_form_url_name` (`url_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_form`
--

LOCK TABLES `cms_form` WRITE;
/*!40000 ALTER TABLE `cms_form` DISABLE KEYS */;
INSERT INTO `cms_form` VALUES (1,'Contact Form','contact','/','Email','2014@denny.me',NULL,1,'2016-11-05 01:18:42');
/*!40000 ALTER TABLE `cms_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_page`
--

DROP TABLE IF EXISTS `cms_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text,
  `template` int(11) NOT NULL,
  `section` int(11) DEFAULT NULL,
  `menu_position` int(11) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_page_url_name` (`section`,`url_name`),
  KEY `cms_page_idx_section` (`section`),
  KEY `cms_page_idx_template` (`template`),
  CONSTRAINT `cms_page_fk_section` FOREIGN KEY (`section`) REFERENCES `cms_section` (`id`),
  CONSTRAINT `cms_page_fk_template` FOREIGN KEY (`template`) REFERENCES `cms_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_page`
--

LOCK TABLES `cms_page` WRITE;
/*!40000 ALTER TABLE `cms_page` DISABLE KEYS */;
INSERT INTO `cms_page` VALUES (1,'Home','home','Home',NULL,1,1,NULL,0,'2016-11-05 01:18:42'),(2,'About Us','about','About Us',NULL,2,2,1,0,'2016-11-05 01:18:42'),(3,'Feature List','features','Feature List',NULL,2,2,2,0,'2016-11-05 01:18:42'),(4,'Contact Us','contact-us','Contact Us',NULL,3,3,1,1,'2016-11-05 01:18:42');
/*!40000 ALTER TABLE `cms_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_page_element`
--

DROP TABLE IF EXISTS `cms_page_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_page_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cms_page_element_idx_page` (`page`),
  CONSTRAINT `cms_page_element_fk_page` FOREIGN KEY (`page`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_page_element`
--

LOCK TABLES `cms_page_element` WRITE;
/*!40000 ALTER TABLE `cms_page_element` DISABLE KEYS */;
INSERT INTO `cms_page_element` VALUES (1,1,'heading1','Short Text','Welcome to the Cloud!','2016-11-05 01:18:42'),(2,1,'html1','HTML','<p style=\"text-align:center\">...</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"CloudForFree.org Logo\" src=\"/static/cms-uploads/images/cloudforfree_logo.png\" style=\"height:359px; width:500px\" /></p>\r\n\r\n<p style=\"text-align:center\">...</p>\r\n','2016-11-05 01:18:42'),(3,1,'video_url','Short Text','','2016-11-05 01:18:42'),(4,2,'heading1','Short Text','Free Cloud Computing Platform','2016-11-05 01:18:42'),(5,2,'paragraphs1','Long Text','CloudForFree offers free public access to a parallel cloud computing platform running Ubuntu GNU/Linux and the RPerl optimizing compiler.','2016-11-05 01:18:42'),(6,2,'html1','HTML','<table border=\"1\">\r\n	<tbody>\r\n		<tr>\r\n			<th colspan=\"2\"><strong>Current Statistics</strong></th>\r\n		</tr>\r\n		<tr>\r\n			<td>Total CPU:</td>\r\n			<td>48 Cores</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Total RAM:</td>\r\n			<td>30 GB</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','2016-11-05 01:18:42'),(7,2,'image1','Image','cloudforfree_logo.png','2016-11-05 01:18:42'),(8,3,'heading1','Short Text','Feature List','2016-11-05 01:18:42'),(9,3,'paragraphs1','Long Text','The following is a list of features currently found on CloudForFree:\r\n','2016-11-05 01:18:42'),(10,3,'html1','HTML','<ul>\r\n	<li>Blogs\r\n	<ul>\r\n		<li>FOO</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>Forums\r\n	<ul>\r\n		<li>FOO&nbsp;</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>News\r\n	<ul>\r\n		<li>FOO</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>Events\r\n	<ul>\r\n		<li>BAR</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>FOO\r\n	<ul>\r\n		<li>BAR</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>&nbsp;</li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>FOO\r\n	<ul>\r\n		<li>BAR</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>FOO\r\n	<ul>\r\n		<li>BAR</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n','2016-11-05 01:18:42'),(11,3,'image1','Image','cloudforfree_logo.png','2016-11-05 01:18:42');
/*!40000 ALTER TABLE `cms_page_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_section`
--

DROP TABLE IF EXISTS `cms_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `default_page` int(11) DEFAULT NULL,
  `menu_position` int(11) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_section_url_name` (`url_name`),
  KEY `cms_section_idx_default_page` (`default_page`),
  CONSTRAINT `cms_section_fk_default_page` FOREIGN KEY (`default_page`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_section`
--

LOCK TABLES `cms_section` WRITE;
/*!40000 ALTER TABLE `cms_section` DISABLE KEYS */;
INSERT INTO `cms_section` VALUES (1,'Home','home',NULL,1,1,0,'2016-11-05 01:18:41'),(2,'About','about',NULL,2,2,0,'2016-11-05 01:18:42'),(3,'Contact','contact',NULL,NULL,3,1,'2016-11-05 08:08:17');
/*!40000 ALTER TABLE `cms_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_template`
--

DROP TABLE IF EXISTS `cms_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `template_file` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_template`
--

LOCK TABLES `cms_template` WRITE;
/*!40000 ALTER TABLE `cms_template` DISABLE KEYS */;
INSERT INTO `cms_template` VALUES (1,'Homepage','homepage.tt','2016-11-05 01:18:41'),(2,'Subpage 1','subpage1.tt','2016-11-05 01:18:41'),(3,'Contact Form','contact-form.tt','2016-11-05 01:18:41');
/*!40000 ALTER TABLE `cms_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_template_element`
--

DROP TABLE IF EXISTS `cms_template_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_template_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cms_template_element_idx_template` (`template`),
  CONSTRAINT `cms_template_element_fk_template` FOREIGN KEY (`template`) REFERENCES `cms_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_template_element`
--

LOCK TABLES `cms_template_element` WRITE;
/*!40000 ALTER TABLE `cms_template_element` DISABLE KEYS */;
INSERT INTO `cms_template_element` VALUES (1,1,'heading1','Short Text','2016-11-05 01:18:41'),(2,1,'html1','HTML','2016-11-05 01:18:41'),(3,1,'video_url','Short Text','2016-11-05 01:18:41'),(4,2,'heading1','Short Text','2016-11-05 01:18:41'),(5,2,'paragraphs1','Long Text','2016-11-05 01:18:41'),(6,2,'html1','HTML','2016-11-05 01:18:41'),(7,2,'image1','Image','2016-11-05 01:18:41');
/*!40000 ALTER TABLE `cms_template_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `discussion` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `author` int(11) DEFAULT NULL,
  `author_type` varchar(20) NOT NULL,
  `author_name` varchar(100) DEFAULT NULL,
  `author_email` varchar(200) DEFAULT NULL,
  `author_link` varchar(200) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `body` text,
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `comment_idx_author` (`author`),
  KEY `comment_idx_discussion` (`discussion`),
  CONSTRAINT `comment_fk_author` FOREIGN KEY (`author`) REFERENCES `user` (`id`),
  CONSTRAINT `comment_fk_discussion` FOREIGN KEY (`discussion`) REFERENCES `discussion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (11,13,1,NULL,1,'Site User',NULL,NULL,NULL,'So Far, So Good!','Of course we\'ve hit a few glitches, which is to be expected in a beta website, but we\'re not letting that slow us down!  :-)','2016-11-05 09:47:26',0);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_like`
--

DROP TABLE IF EXISTS `comment_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `ip_address` varchar(15) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `comment_like_idx_comment` (`comment`),
  KEY `comment_like_idx_user` (`user`),
  CONSTRAINT `comment_like_fk_comment` FOREIGN KEY (`comment`) REFERENCES `comment` (`uid`),
  CONSTRAINT `comment_like_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_like`
--

LOCK TABLES `comment_like` WRITE;
/*!40000 ALTER TABLE `comment_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `confirmation`
--

DROP TABLE IF EXISTS `confirmation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `confirmation` (
  `user` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user`,`code`),
  KEY `confirmation_idx_user` (`user`),
  CONSTRAINT `confirmation_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `confirmation`
--

LOCK TABLES `confirmation` WRITE;
/*!40000 ALTER TABLE `confirmation` DISABLE KEYS */;
INSERT INTO `confirmation` VALUES (5,'8562ecdaa4625d69dbeaf76c2f0fa31b','2016-11-05 10:07:34');
/*!40000 ALTER TABLE `confirmation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion`
--

DROP TABLE IF EXISTS `discussion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `resource_type` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion`
--

LOCK TABLES `discussion` WRITE;
/*!40000 ALTER TABLE `discussion` DISABLE KEYS */;
INSERT INTO `discussion` VALUES (1,1,'BlogPost','2016-11-05 01:20:21'),(2,2,'BlogPost','2016-11-05 01:20:23'),(3,3,'BlogPost','2016-11-05 01:20:23'),(4,4,'BlogPost','2016-11-05 01:20:23'),(5,5,'BlogPost','2016-11-05 01:20:23'),(6,7,'BlogPost','2016-11-05 01:20:24'),(7,8,'BlogPost','2016-11-05 01:20:24'),(8,9,'BlogPost','2016-11-05 01:20:24'),(9,10,'BlogPost','2016-11-05 01:20:25'),(10,11,'BlogPost','2016-11-05 01:20:25'),(11,12,'BlogPost','2016-11-05 01:20:25'),(12,13,'BlogPost','2016-11-05 01:20:26'),(13,1,'ForumPost','2016-11-05 01:20:50'),(14,1,'ShopItem','2016-11-05 01:21:21'),(15,2,'ShopItem','2016-11-05 01:21:21'),(16,3,'ShopItem','2016-11-05 01:21:21');
/*!40000 ALTER TABLE `discussion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `image` varchar(100) DEFAULT NULL,
  `start_date` timestamp NOT NULL DEFAULT '1971-01-01 06:01:01',
  `end_date` timestamp NOT NULL DEFAULT '1971-01-01 06:01:01',
  `address` varchar(250) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `booking_link` varchar(200) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'Halloween RPerl Release','halloween_rperl_release','Spooky!','','2016-10-31 04:00:00','2016-10-31 04:00:00','','','','','',0),(2,'Thanksgiving RPerl Release','thanksgiving_rperl_release','Gobble gobble!','norman_rockwell_thanksgiving.jpg','2016-11-24 05:00:00','2016-11-24 05:00:00','','','','','',0),(3,'Christmas RPerl Release','christmas_rperl_release','Tis the season to be jolly, tra-la-la-la-la, la-la la la.','camel_christmas_hat.jpg','2016-12-25 05:00:00','2016-12-25 05:00:00','','','','','',0);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `last_checked` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed`
--

LOCK TABLES `feed` WRITE;
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed_item`
--

DROP TABLE IF EXISTS `feed_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `feed` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `body` text,
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `feed_item_idx_feed` (`feed`),
  CONSTRAINT `feed_item_fk_feed` FOREIGN KEY (`feed`) REFERENCES `feed` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_item`
--

LOCK TABLES `feed_item` WRITE;
/*!40000 ALTER TABLE `feed_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_access`
--

DROP TABLE IF EXISTS `file_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `access_group` varchar(50) NOT NULL,
  `filepath` varchar(250) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `file_access_idx_user` (`user`),
  CONSTRAINT `file_access_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_access`
--

LOCK TABLES `file_access` WRITE;
/*!40000 ALTER TABLE `file_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum`
--

DROP TABLE IF EXISTS `forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `display_order` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_url_name` (`section`,`url_name`),
  KEY `forum_idx_section` (`section`),
  CONSTRAINT `forum_fk_section` FOREIGN KEY (`section`) REFERENCES `forum_section` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum`
--

LOCK TABLES `forum` WRITE;
/*!40000 ALTER TABLE `forum` DISABLE KEYS */;
INSERT INTO `forum` VALUES (1,1,'Back-End Computing Platform','back_end_computing_platform','Issues & Questions Related To The CloudForFree Parallel Linux Operating System',2,'2016-11-05 01:20:49'),(2,1,'Front-End User Interface','front_end_user_interface','Issues & Questions Related To The CloudForFree Web-Based Graphical User Interface',1,'2016-11-05 01:20:50'),(3,2,'Syntax Help','rperl_tech_support_syntax','Issues & Questions Related To RPerl Computer Language Programming Syntax',1,'2016-11-05 01:20:50');
/*!40000 ALTER TABLE `forum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_post`
--

DROP TABLE IF EXISTS `forum_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url_title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `author` int(11) DEFAULT NULL,
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `display_order` int(11) DEFAULT NULL,
  `commented_on` timestamp NOT NULL DEFAULT '1971-01-01 06:01:01',
  `discussion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_post_idx_author` (`author`),
  KEY `forum_post_idx_discussion` (`discussion`),
  KEY `forum_post_idx_forum` (`forum`),
  CONSTRAINT `forum_post_fk_author` FOREIGN KEY (`author`) REFERENCES `user` (`id`),
  CONSTRAINT `forum_post_fk_discussion` FOREIGN KEY (`discussion`) REFERENCES `discussion` (`id`),
  CONSTRAINT `forum_post_fk_forum` FOREIGN KEY (`forum`) REFERENCES `forum` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_post`
--

LOCK TABLES `forum_post` WRITE;
/*!40000 ALTER TABLE `forum_post` DISABLE KEYS */;
INSERT INTO `forum_post` VALUES (1,2,'Beta Website Problems','beta_website_problems','New Users Come Here For Help',1,'2016-11-05 01:20:50',NULL,'2016-11-05 13:48:16',13);
/*!40000 ALTER TABLE `forum_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_section`
--

DROP TABLE IF EXISTS `forum_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `display_order` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_section_url_name` (`url_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_section`
--

LOCK TABLES `forum_section` WRITE;
/*!40000 ALTER TABLE `forum_section` DISABLE KEYS */;
INSERT INTO `forum_section` VALUES (1,'CloudForFree Tech Support','cloudforfree_tech_support','Issues Related To CloudForFree Computing Platform & User Interface',1,'2016-11-05 01:20:49'),(2,'RPerl Tech Support','rperl_tech_support','Issues Related To RPerl Optimizing Compiler',2,'2016-11-05 01:20:49'),(3,'CloudForFree & RPerl Community','cloudforfree_rperl_community','Non-Technical Discussions Related To CloudForFree & RPerl',3,'2016-11-05 09:05:06'),(4,'RPerl Apps, HardwarePerl','rperl_apps_hardwareperl','Discussions Related To HardwarePerl Application Suite',4,'2016-11-05 09:07:04'),(5,'RPerl Apps, StandardPerl','rperl_apps_standardperl','Discussions Related To StandardPerl Application Suite',5,'2016-11-05 09:08:56'),(6,'RPerl Apps, GraphicsPerl','rperl_apps_graphicsperl','Discussions Related To GrahpicsPerl Application Suite',6,'2016-11-05 09:12:20'),(7,'RPerl Apps, DataPerl','rperl_apps_dataperl','Discussions Related To DataPerl Application Suite',7,'2016-11-05 09:12:55'),(8,'RPerl Apps, SignalPerl','rperl_apps_signalperl','Discussions Related To SignalPerl Application Suite',8,'2016-11-05 09:13:25'),(9,'RPerl Apps, CryptoPerl','rperl_apps_cryptoperl','Discussions Related To CryptoPerl Application Suite',9,'2016-11-05 09:14:07'),(10,'RPerl Apps, LogicPerl','rperl_apps_logicperl','Discussions Related To LogicPerl Application Suite',10,'2016-11-05 09:14:42'),(11,'RPerl Apps, MathPerl','rperl_apps_mathperl','Discussions Related To MathPerl Application Suite',11,'2016-11-05 09:15:29'),(12,'RPerl Apps, StatisticsPerl','rperl_apps_statisticsperl','Discussions Related To StatisticsPerl Application Suite',12,'2016-11-05 09:16:09'),(13,'RPerl Apps, PhysicsPerl','rperl_apps_physicsperl','Discussions Related To PhysicsPerl Application Suite',13,'2016-11-05 09:17:34');
/*!40000 ALTER TABLE `forum_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery`
--

LOCK TABLES `gallery` WRITE;
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `mime` varchar(200) NOT NULL,
  `path` text NOT NULL,
  `caption` text,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_recipient`
--

DROP TABLE IF EXISTS `mail_recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_recipient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `token` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail_recipient_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_recipient`
--

LOCK TABLES `mail_recipient` WRITE;
/*!40000 ALTER TABLE `mail_recipient` DISABLE KEYS */;
INSERT INTO `mail_recipient` VALUES (1,'Nice Person','nice.person@example.com','abcd1234abcd1234abcd1234abcd1111','2016-11-05 01:21:41'),(2,'Another Person','another.person@example.com','abcd1234abcd1234abcd1234abcd2222','2016-11-05 01:21:41'),(3,'A. Teacher','a.teacher@example.com','abcd1234abcd1234abcd1234abcd3333','2016-11-05 01:21:41'),(4,'Site Admin','changeme@example.com','abcd1234abcd1234abcd1234abcd4444','2016-11-05 01:21:41');
/*!40000 ALTER TABLE `mail_recipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mailing_list`
--

DROP TABLE IF EXISTS `mailing_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mailing_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_can_sub` tinyint(4) DEFAULT '0',
  `user_can_unsub` tinyint(4) DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mailing_list`
--

LOCK TABLES `mailing_list` WRITE;
/*!40000 ALTER TABLE `mailing_list` DISABLE KEYS */;
INSERT INTO `mailing_list` VALUES (1,'Donators and teachers',0,1,'2016-11-05 01:21:41'),(2,'Testing',0,1,'2016-11-05 01:21:41');
/*!40000 ALTER TABLE `mailing_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_item`
--

DROP TABLE IF EXISTS `news_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url_title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `related_url` varchar(255) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `news_item_idx_author` (`author`),
  CONSTRAINT `news_item_fk_author` FOREIGN KEY (`author`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_item`
--

LOCK TABLES `news_item` WRITE;
/*!40000 ALTER TABLE `news_item` DISABLE KEYS */;
INSERT INTO `news_item` VALUES (1,2,'Website Beta Launch!','website_beta_launch','<p>We are excited to announce the beta version of CloudForFree!</p>\r\n','',0,'2016-11-05 07:00:00'),(2,2,'Extra extra','extra-extra','<p>Read all about it.</p>\r\n','',1,'2010-01-01 18:00:00'),(3,2,'Filler story','filler','<p>Nothing of interest here. Move along.</p>\r\n','',1,'2010-01-02 18:00:00');
/*!40000 ALTER TABLE `news_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `url_title` varchar(100) NOT NULL,
  `template` int(11) NOT NULL,
  `plaintext` text,
  `list` int(11) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Not sent',
  `sent` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `newsletter_idx_list` (`list`),
  KEY `newsletter_idx_template` (`template`),
  CONSTRAINT `newsletter_fk_list` FOREIGN KEY (`list`) REFERENCES `mailing_list` (`id`),
  CONSTRAINT `newsletter_fk_template` FOREIGN KEY (`template`) REFERENCES `newsletter_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter`
--

LOCK TABLES `newsletter` WRITE;
/*!40000 ALTER TABLE `newsletter` DISABLE KEYS */;
INSERT INTO `newsletter` VALUES (1,'Donations and a word to teachers and librarians','donations',1,'If you enjoyed the electronic edition of Little Brother and you want to donate \nsomething to say thanks, go to http://craphound.com/littlebrother/donate/ and \nfind a teacher or librarian you want to support.  Then go to Amazon, BN.com, \nor your favorite electronic bookseller and order a copy to the classroom, \nthen email a copy of the receipt (feel free to delete your address and other \npersonal info first!) to freelittlebrother@gmail.com so that Olga can mark \nthat copy as sent.  If you don\'t want to be publicly acknowledged for your \ngenerosity, let us know and we\'ll keep you anonymous, otherwise we\'ll thank \nyou on the donate page.\n',1,'Not sent','2016-11-05 01:21:42');
/*!40000 ALTER TABLE `newsletter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_element`
--

DROP TABLE IF EXISTS `newsletter_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsletter` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `newsletter_element_idx_newsletter` (`newsletter`),
  CONSTRAINT `newsletter_element_fk_newsletter` FOREIGN KEY (`newsletter`) REFERENCES `newsletter` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_element`
--

LOCK TABLES `newsletter_element` WRITE;
/*!40000 ALTER TABLE `newsletter_element` DISABLE KEYS */;
INSERT INTO `newsletter_element` VALUES (1,1,'body','HTML','<p>	A message from Cory Doctorow:\n</p>\n<p>	Every time I put a book online for free, I get emails from readers who \n	want to send me donations for the book. I appreciate their generous\n	spirit, but I\'m not interested in cash donations, because my\n	publishers are really important to me. They contribute immeasurably\n	to the book, improving it, introducing it to an audience I could never\n	reach, helping me do more with my work. I have no desire to cut them\n	out of the loop.\n</p>\n\n<p>	But there has to be some good way to turn that generosity to good use,\n	and I think I\'ve found it.\n</p>\n\n<p>	Here\'s the deal: there are lots of teachers and librarians who\'d love to \n	get hard-copies of Little Brother into their kids\' hands, but don\'t have the\n	budget for it (teachers in the US spend around $1,200 out of pocket\n	each on classroom supplies that their budgets won\'t stretch to cover,\n	which is why I sponsor a classroom at Ivanhoe Elementary in my old\n	neighborhood in Los Angeles; you can adopt a class yourself \n	<a href=\"http://www.adoptaclassroom.org/\">here</a>).\n</p>\n\n<p>	There are generous people who want to send some cash my way to thank me \n	for the free ebooks.\n</p>\n\n<p>	I\'m proposing that we put them together. \n</p>\n\n<p>	If you\'re a teacher or librarian and you want a free copy of Little\n	Brother, email \n	<a href=\"mailto:freelittlebrother@gmail.com\">freelittlebrother@gmail.com</a> \n	with your name and the name and address of your school. It\'ll be \n	<a href=\"http://craphound.com/littlebrother/donate/\">posted to my site</a> \n	by my fantastic helper, Olga Nunes, so that potential donors can see it.\n</p>\n\n<p>	If you enjoyed the electronic edition of Little Brother and you want to\n	donate something to say thanks, \n	<a href=\"http://craphound.com/littlebrother/donate/\">go here</a> \n	and find a teacher or librarian you want to support. Then go to Amazon, \n	BN.com, or your favorite electronic bookseller and order a copy to the\n	classroom, then email a copy of the receipt (feel free to delete your\n	address and other personal info first!) to\n	<a href=\"mailto:freelittlebrother@gmail.com\">freelittlebrother@gmail.com</a> \n	so that Olga can mark that copy as sent. If you don\'t want to be publicly \n	acknowledged for your generosity, let us know and we\'ll keep you \n	anonymous, otherwise we\'ll thank you on the donate page.\n</p>\n\n<p>	I have no idea if this will end up with hundreds, dozens or just a few\n	copies going out -- but I have high hopes!\n</p>\n','2016-11-05 01:21:42');
/*!40000 ALTER TABLE `newsletter_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_template`
--

DROP TABLE IF EXISTS `newsletter_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_template`
--

LOCK TABLES `newsletter_template` WRITE;
/*!40000 ALTER TABLE `newsletter_template` DISABLE KEYS */;
INSERT INTO `newsletter_template` VALUES (1,'Example newsletter template','example.tt','2016-11-05 01:21:42');
/*!40000 ALTER TABLE `newsletter_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_template_element`
--

DROP TABLE IF EXISTS `newsletter_template_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_template_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `newsletter_template_element_idx_template` (`template`),
  CONSTRAINT `newsletter_template_element_fk_template` FOREIGN KEY (`template`) REFERENCES `newsletter_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_template_element`
--

LOCK TABLES `newsletter_template_element` WRITE;
/*!40000 ALTER TABLE `newsletter_template_element` DISABLE KEYS */;
INSERT INTO `newsletter_template_element` VALUES (1,1,'body','HTML','2016-11-05 01:21:42');
/*!40000 ALTER TABLE `newsletter_template_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` char(72) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `email` varchar(250) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `billing_address` text NOT NULL,
  `billing_town` varchar(100) NOT NULL,
  `billing_county` varchar(50) DEFAULT NULL,
  `billing_country` varchar(50) NOT NULL,
  `billing_postcode` varchar(10) NOT NULL,
  `delivery_address` text,
  `delivery_town` varchar(100) DEFAULT NULL,
  `delivery_county` varchar(50) DEFAULT NULL,
  `delivery_country` varchar(50) DEFAULT NULL,
  `delivery_postcode` varchar(10) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Checkout incomplete',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `despatched` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_idx_session` (`session`),
  KEY `order_idx_user` (`user`),
  CONSTRAINT `order_fk_session` FOREIGN KEY (`session`) REFERENCES `session` (`id`),
  CONSTRAINT `order_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `unit_price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `postage` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_item_idx_item` (`item`),
  KEY `order_item_idx_order` (`order`),
  KEY `order_item_idx_postage` (`postage`),
  CONSTRAINT `order_item_fk_item` FOREIGN KEY (`item`) REFERENCES `shop_item` (`id`),
  CONSTRAINT `order_item_fk_order` FOREIGN KEY (`order`) REFERENCES `order` (`id`),
  CONSTRAINT `order_item_fk_postage` FOREIGN KEY (`postage`) REFERENCES `postage_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item_attribute`
--

DROP TABLE IF EXISTS `order_item_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_item_attribute_idx_item` (`item`),
  CONSTRAINT `order_item_attribute_fk_item` FOREIGN KEY (`item`) REFERENCES `order_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item_attribute`
--

LOCK TABLES `order_item_attribute` WRITE;
/*!40000 ALTER TABLE `order_item_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paid_list`
--

DROP TABLE IF EXISTS `paid_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paid_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `mailing_list` int(11) DEFAULT NULL,
  `has_captcha` tinyint(4) DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paid_list`
--

LOCK TABLES `paid_list` WRITE;
/*!40000 ALTER TABLE `paid_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `paid_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paid_list_email`
--

DROP TABLE IF EXISTS `paid_list_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paid_list_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paid_list` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `template` int(11) NOT NULL,
  `delay` int(11) NOT NULL,
  `plaintext` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `paid_list_email_idx_paid_list` (`paid_list`),
  KEY `paid_list_email_idx_template` (`template`),
  CONSTRAINT `paid_list_email_fk_paid_list` FOREIGN KEY (`paid_list`) REFERENCES `paid_list` (`id`),
  CONSTRAINT `paid_list_email_fk_template` FOREIGN KEY (`template`) REFERENCES `newsletter_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paid_list_email`
--

LOCK TABLES `paid_list_email` WRITE;
/*!40000 ALTER TABLE `paid_list_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `paid_list_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paid_list_email_element`
--

DROP TABLE IF EXISTS `paid_list_email_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paid_list_email_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `paid_list_email_element_idx_email` (`email`),
  CONSTRAINT `paid_list_email_element_fk_email` FOREIGN KEY (`email`) REFERENCES `paid_list_email` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paid_list_email_element`
--

LOCK TABLES `paid_list_email_element` WRITE;
/*!40000 ALTER TABLE `paid_list_email_element` DISABLE KEYS */;
/*!40000 ALTER TABLE `paid_list_email_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_anon_vote`
--

DROP TABLE IF EXISTS `poll_anon_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_anon_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `poll_anon_vote_idx_answer` (`answer`),
  KEY `poll_anon_vote_idx_question` (`question`),
  CONSTRAINT `poll_anon_vote_fk_answer` FOREIGN KEY (`answer`) REFERENCES `poll_answer` (`id`),
  CONSTRAINT `poll_anon_vote_fk_question` FOREIGN KEY (`question`) REFERENCES `poll_question` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_anon_vote`
--

LOCK TABLES `poll_anon_vote` WRITE;
/*!40000 ALTER TABLE `poll_anon_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_anon_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_answer`
--

DROP TABLE IF EXISTS `poll_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` int(11) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `poll_answer_idx_question` (`question`),
  CONSTRAINT `poll_answer_fk_question` FOREIGN KEY (`question`) REFERENCES `poll_question` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_answer`
--

LOCK TABLES `poll_answer` WRITE;
/*!40000 ALTER TABLE `poll_answer` DISABLE KEYS */;
INSERT INTO `poll_answer` VALUES (1,1,'Here','2016-11-05 01:22:29'),(2,1,'There','2016-11-05 01:22:29');
/*!40000 ALTER TABLE `poll_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_question`
--

DROP TABLE IF EXISTS `poll_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) NOT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_question`
--

LOCK TABLES `poll_question` WRITE;
/*!40000 ALTER TABLE `poll_question` DISABLE KEYS */;
INSERT INTO `poll_question` VALUES (1,'Poll goes where?',0,'2016-11-05 01:22:28');
/*!40000 ALTER TABLE `poll_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_user_vote`
--

DROP TABLE IF EXISTS `poll_user_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_user_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `poll_user_vote_idx_answer` (`answer`),
  KEY `poll_user_vote_idx_question` (`question`),
  KEY `poll_user_vote_idx_user` (`user`),
  CONSTRAINT `poll_user_vote_fk_answer` FOREIGN KEY (`answer`) REFERENCES `poll_answer` (`id`),
  CONSTRAINT `poll_user_vote_fk_question` FOREIGN KEY (`question`) REFERENCES `poll_question` (`id`),
  CONSTRAINT `poll_user_vote_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_user_vote`
--

LOCK TABLES `poll_user_vote` WRITE;
/*!40000 ALTER TABLE `poll_user_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_user_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postage_option`
--

DROP TABLE IF EXISTS `postage_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postage_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `description` text,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postage_option`
--

LOCK TABLES `postage_option` WRITE;
/*!40000 ALTER TABLE `postage_option` DISABLE KEYS */;
INSERT INTO `postage_option` VALUES (1,'Standard',2.22,NULL,0,'2016-11-05 01:21:20'),(2,'Special',3.33,NULL,0,'2016-11-05 01:21:20'),(3,'Gold',5.55,NULL,0,'2016-11-05 01:21:20');
/*!40000 ALTER TABLE `postage_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queued_email`
--

DROP TABLE IF EXISTS `queued_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queued_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` int(11) NOT NULL,
  `recipient` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `send` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Not sent',
  PRIMARY KEY (`id`),
  KEY `queued_email_idx_email` (`email`),
  KEY `queued_email_idx_recipient` (`recipient`),
  CONSTRAINT `queued_email_fk_email` FOREIGN KEY (`email`) REFERENCES `autoresponder_email` (`id`),
  CONSTRAINT `queued_email_fk_recipient` FOREIGN KEY (`recipient`) REFERENCES `mail_recipient` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queued_email`
--

LOCK TABLES `queued_email` WRITE;
/*!40000 ALTER TABLE `queued_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `queued_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queued_paid_email`
--

DROP TABLE IF EXISTS `queued_paid_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queued_paid_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` int(11) NOT NULL,
  `recipient` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `send` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Not sent',
  PRIMARY KEY (`id`),
  KEY `queued_paid_email_idx_email` (`email`),
  KEY `queued_paid_email_idx_recipient` (`recipient`),
  CONSTRAINT `queued_paid_email_fk_email` FOREIGN KEY (`email`) REFERENCES `paid_list_email` (`id`),
  CONSTRAINT `queued_paid_email_fk_recipient` FOREIGN KEY (`recipient`) REFERENCES `mail_recipient` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queued_paid_email`
--

LOCK TABLES `queued_paid_email` WRITE;
/*!40000 ALTER TABLE `queued_paid_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `queued_paid_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'CMS Page Editor','2016-11-05 01:18:18'),(2,'CMS Page Admin','2016-11-05 01:18:18'),(3,'CMS Template Admin','2016-11-05 01:18:18'),(4,'CMS Form Admin','2016-11-05 01:18:18'),(5,'Shared Content Editor','2016-11-05 01:18:18'),(6,'File Admin','2016-11-05 01:18:18'),(7,'News Admin','2016-11-05 01:18:18'),(8,'Blog Author','2016-11-05 01:18:18'),(9,'Blog Admin','2016-11-05 01:18:18'),(10,'Forums Admin','2016-11-05 01:18:18'),(11,'Comment Moderator','2016-11-05 01:18:19'),(12,'Poll Admin','2016-11-05 01:18:19'),(13,'Events Admin','2016-11-05 01:18:19'),(14,'Shop Admin','2016-11-05 01:18:19'),(15,'Newsletter Admin','2016-11-05 01:18:19'),(16,'Newsletter Template Admin','2016-11-05 01:18:19'),(17,'User Admin','2016-11-05 01:18:19');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `id` char(72) NOT NULL DEFAULT '',
  `session_data` text,
  `expires` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('session:12ef8969f4d6f795b65a0641d988d1fbdf514875','BQkDAAAAAQlYHZXbAAAACV9fdXBkYXRlZA==\n',1478383055,'2016-11-05 08:18:35'),('session:279795c350994a029f9b9bacfcebda654fe874da','BQkDAAAAAglYHY32AAAACV9fdXBkYXRlZAQDAAAABBcSd2JyYXN3ZWxsQGh1c2guY29tAAAABWVt\nYWlsFwl0ZXN0X3Bhc3MAAAAJcGFzc3dvcmQyFwl0ZXN0X3Bhc3MAAAAIcGFzc3dvcmQXCXRlc3Rf\ndXNlcgAAAAh1c2VybmFtZQAAAAdfX2ZsYXNo\n',1478375091,'2016-11-05 07:44:51'),('session:509296ac76de1aff6ead56e1b3686512d2b7e9db','BQkDAAAABAoHZGVmYXVsdAAAAAxfX3VzZXJfcmVhbG0JWB0/HQAAAAlfX2NyZWF0ZWQEAwAAABIK\nB0RlZmF1bHQAAAAJZmlyc3RuYW1lBQAAAAtwcm9maWxlX3BpYwUAAAANZGlzcGxheV9lbWFpbAoF\nQWRtaW4AAAAHc3VybmFtZQUAAAAIcG9zdGNvZGUKBWFkbWluAAAACHVzZXJuYW1lCr9UaGlzIGlz\nIHRoZSBkZWZhdWx0IGFkbWluIHVzZXIgYWNjb3VudC4gIFBsZWFzZSBlaXRoZXIgcmVtb3ZlIGl0\nIGJlZm9yZSBwdXR0aW5nIHlvdXIgc2l0ZSBvbmxpbmUsIG9yIGF0IGxlYXN0IG1ha2Ugc3VyZSB0\naGF0IHlvdSBjaGFuZ2UgdGhlIHBhc3N3b3JkIC0gYW5kIHByZWZlcmFibHksIGNoYW5nZSB0aGUg\ndXNlcm5hbWUgdG9vIQAAAAthZG1pbl9ub3RlcwoFQWRtaW4AAAAMZGlzcGxheV9uYW1lBQAAAANi\naW8KATAAAAAPZm9yZ290X3Bhc3N3b3JkBQAAAApkaXNjdXNzaW9uCgExAAAABmFjdGl2ZQpKNGZh\nYzkzNTM1MDQ1OGUzMDcyMjY1NDYyNDA4ZGMxZDM1ZjM2ZDNmYjJlY2UyNTE0NGYzOTk3MWJhYWRi\nOWNjMjZyQUw2VT1vYmgAAAAIcGFzc3dvcmQFAAAAB3dlYnNpdGUKATEAAAACaWQKEzIwMTYtMTEt\nMDQgMjE6MTg6MTkAAAAHY3JlYXRlZAoUY2hhbmdlbWVAZXhhbXBsZS5jb20AAAAFZW1haWwFAAAA\nCGxvY2F0aW9uAAAABl9fdXNlcglYHazSAAAACV9fdXBkYXRlZA==\n',1478385754,'2016-11-05 02:08:29'),('session:5fe3a5da8c87b3c144e2cd747c1d9463f9328bc6','BQkDAAAAAQlYHa+WAAAACV9fdXBkYXRlZA==\n',1478383702,'2016-11-05 10:07:34'),('session:c823f9dedd8e06f93b11d289404501afc3c8d044','BQoDAAAABAlYI3fGAAAACV9fdXBkYXRlZAlYI3JAAAAACV9fY3JlYXRlZAQDAAAAEgUAAAANZGlz\ncGxheV9lbWFpbAoHRGVmYXVsdAAAAAlmaXJzdG5hbWUFAAAACmRpc2N1c3Npb24FAAAACHBvc3Rj\nb2RlCgExAAAAAmlkCgVhZG1pbgAAAAh1c2VybmFtZQpKNGZhYzkzNTM1MDQ1OGUzMDcyMjY1NDYy\nNDA4ZGMxZDM1ZjM2ZDNmYjJlY2UyNTE0NGYzOTk3MWJhYWRiOWNjMjZyQUw2VT1vYmgAAAAIcGFz\nc3dvcmQKATAAAAAPZm9yZ290X3Bhc3N3b3JkCgVBZG1pbgAAAAdzdXJuYW1lChRjaGFuZ2VtZUBl\neGFtcGxlLmNvbQAAAAVlbWFpbAq/VGhpcyBpcyB0aGUgZGVmYXVsdCBhZG1pbiB1c2VyIGFjY291\nbnQuICBQbGVhc2UgZWl0aGVyIHJlbW92ZSBpdCBiZWZvcmUgcHV0dGluZyB5b3VyIHNpdGUgb25s\naW5lLCBvciBhdCBsZWFzdCBtYWtlIHN1cmUgdGhhdCB5b3UgY2hhbmdlIHRoZSBwYXNzd29yZCAt\nIGFuZCBwcmVmZXJhYmx5LCBjaGFuZ2UgdGhlIHVzZXJuYW1lIHRvbyEAAAALYWRtaW5fbm90ZXMF\nAAAAC3Byb2ZpbGVfcGljBQAAAAd3ZWJzaXRlBQAAAAhsb2NhdGlvbgoBMQAAAAZhY3RpdmUKBUFk\nbWluAAAADGRpc3BsYXlfbmFtZQoTMjAxNi0xMS0wNCAyMDoxODoxOQAAAAdjcmVhdGVkBQAAAANi\naW8AAAAGX191c2VyCgdkZWZhdWx0AAAADF9fdXNlcl9yZWFsbQ==\n',1478762630,'2016-11-09 19:00:16'),('session:d2f9d6061748a89fab53c2bc793b66d6bf25b341','BQkDAAAABAoHZGVmYXVsdAAAAAxfX3VzZXJfcmVhbG0EAwAAABIKATQAAAACaWQFAAAADGRpc3Bs\nYXlfbmFtZQUAAAAIcG9zdGNvZGUFAAAACWZpcnN0bmFtZQUAAAADYmlvBQAAAAthZG1pbl9ub3Rl\ncwUAAAAHd2Vic2l0ZQUAAAALcHJvZmlsZV9waWMKCnRlc3RhZG1pbjIAAAAIdXNlcm5hbWUFAAAA\nCmRpc2N1c3Npb24KEzIwMTYtMTEtMDQgMjE6NTU6NDkAAAAHY3JlYXRlZAoBMAAAAA9mb3Jnb3Rf\ncGFzc3dvcmQKATEAAAAGYWN0aXZlCko1OWM5ODU2ZDgzNGZkNTUwZjQ4N2RkZDc4YmQwYTQ4ZjMy\nYzEyODRiNzhjNzkwNTBlYTdmZGM4ZWQ1ODc3YmE5bndjWWxVR2s0TwAAAAhwYXNzd29yZAUAAAAI\nbG9jYXRpb24FAAAADWRpc3BsYXlfZW1haWwKE25vbnN1Y2hAZXhhbXBsZS5jb20AAAAFZW1haWwF\nAAAAB3N1cm5hbWUAAAAGX191c2VyCVgdPCUAAAAJX19jcmVhdGVkCVgdPCUAAAAJX191cGRhdGVk\n',1478354149,'2016-11-05 01:55:49'),('session:e85557764c45b90256851d7dc1f1e631cccca4c5','BQoDAAAAAwQDAAAAEgUAAAAHd2Vic2l0ZQUAAAALcHJvZmlsZV9waWMFAAAACGxvY2F0aW9uBQAA\nAAdzdXJuYW1lBQAAAAthZG1pbl9ub3RlcwoSd2JyYXN3ZWxsQGh1c2guY29tAAAABWVtYWlsCgEw\nAAAAD2ZvcmdvdF9wYXNzd29yZApKMTgzNTNjNjYyNWIxOTM5NjFhZmRmNjJjMjNlODEwYmQ3ZjE2\nODdmYzE3NjI5ZDNhNTFhOWZjZGQ2YTFiZjY5MkRjeC9RYzBhbHQAAAAIcGFzc3dvcmQKATQAAAAC\naWQKCXdicmFzd2VsbAAAAAh1c2VybmFtZQUAAAADYmlvBQAAAAxkaXNwbGF5X25hbWUKEzIwMTYt\nMTEtMDUgMDI6NDQ6NTEAAAAHY3JlYXRlZAoBMQAAAAZhY3RpdmUFAAAACWZpcnN0bmFtZQUAAAAN\nZGlzcGxheV9lbWFpbAUAAAAIcG9zdGNvZGUFAAAACmRpc2N1c3Npb24AAAAGX191c2VyCVgjdeQA\nAAAJX191cGRhdGVkCgdkZWZhdWx0AAAADF9fdXNlcl9yZWFsbQ==\n',1478762638,'2016-11-09 19:08:53');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shared_content`
--

DROP TABLE IF EXISTS `shared_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shared_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shared_content`
--

LOCK TABLES `shared_content` WRITE;
/*!40000 ALTER TABLE `shared_content` DISABLE KEYS */;
INSERT INTO `shared_content` VALUES (1,'site_tagline','Short Text','It\'s All Yours...','2016-11-05 01:19:02'),(2,'powered_by','Long Text','Powered by <a href=\"http://shinycms.org/\">ShinyCMS</a>','2016-11-05 01:19:02');
/*!40000 ALTER TABLE `shared_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_category`
--

DROP TABLE IF EXISTS `shop_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(100) NOT NULL,
  `description` text,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_category_url_name` (`url_name`),
  KEY `shop_category_idx_parent` (`parent`),
  CONSTRAINT `shop_category_fk_parent` FOREIGN KEY (`parent`) REFERENCES `shop_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_category`
--

LOCK TABLES `shop_category` WRITE;
/*!40000 ALTER TABLE `shop_category` DISABLE KEYS */;
INSERT INTO `shop_category` VALUES (1,NULL,'Widgets','widgets','This is the widgets section.',0,'2016-11-05 01:21:19'),(2,NULL,'Doodahs','doodahs','This is the doodahs section.',0,'2016-11-05 01:21:19'),(3,1,'Ambidextrous Widgets','ambi-widgets','This is the section for ambidextrous widgets.',0,'2016-11-05 01:21:19');
/*!40000 ALTER TABLE `shop_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_item`
--

DROP TABLE IF EXISTS `shop_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `code` varchar(100) NOT NULL,
  `description` text,
  `image` varchar(200) DEFAULT NULL,
  `price` decimal(9,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `restock_date` datetime DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `discussion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_item_product_code` (`code`),
  KEY `shop_item_idx_discussion` (`discussion`),
  KEY `shop_item_idx_product_type` (`product_type`),
  CONSTRAINT `shop_item_fk_discussion` FOREIGN KEY (`discussion`) REFERENCES `discussion` (`id`),
  CONSTRAINT `shop_item_fk_product_type` FOREIGN KEY (`product_type`) REFERENCES `shop_product_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_item`
--

LOCK TABLES `shop_item` WRITE;
/*!40000 ALTER TABLE `shop_item` DISABLE KEYS */;
INSERT INTO `shop_item` VALUES (1,1,'Blue left-handed widget','blue-lh-widget','A blue widget, suitable for left-handed applications.','blue-dog.jpg',3.14,NULL,NULL,0,'2016-11-05 01:21:20',NULL,14),(2,2,'Red right-handed widget','red-rh-widget','A red widget, suitable for right-handed applications.','redphanatic.jpg',2.72,NULL,NULL,0,'2016-11-05 01:21:20',NULL,15),(3,1,'Green ambidextrous widget','green-ambi-widget','A green widget; swings both ways.','razer.jpg',1.23,NULL,NULL,0,'2016-11-05 01:21:20',NULL,16),(4,3,'Green T-shirt','green-t-shirt','T-shirt with green design.','razer.jpg',5.15,NULL,NULL,0,'2016-11-05 01:21:20',NULL,NULL);
/*!40000 ALTER TABLE `shop_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_item_category`
--

DROP TABLE IF EXISTS `shop_item_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_item_category` (
  `item` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`item`,`category`),
  KEY `shop_item_category_idx_category` (`category`),
  KEY `shop_item_category_idx_item` (`item`),
  CONSTRAINT `shop_item_category_fk_category` FOREIGN KEY (`category`) REFERENCES `shop_category` (`id`),
  CONSTRAINT `shop_item_category_fk_item` FOREIGN KEY (`item`) REFERENCES `shop_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_item_category`
--

LOCK TABLES `shop_item_category` WRITE;
/*!40000 ALTER TABLE `shop_item_category` DISABLE KEYS */;
INSERT INTO `shop_item_category` VALUES (1,1,'2016-11-05 01:21:21'),(2,1,'2016-11-05 01:21:21'),(3,1,'2016-11-05 01:21:21'),(3,3,'2016-11-05 01:21:21');
/*!40000 ALTER TABLE `shop_item_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_item_element`
--

DROP TABLE IF EXISTS `shop_item_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_item_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `shop_item_element_idx_item` (`item`),
  CONSTRAINT `shop_item_element_fk_item` FOREIGN KEY (`item`) REFERENCES `shop_item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_item_element`
--

LOCK TABLES `shop_item_element` WRITE;
/*!40000 ALTER TABLE `shop_item_element` DISABLE KEYS */;
INSERT INTO `shop_item_element` VALUES (1,1,'paypal_button','Long Text','<form target=\"paypal\" action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\">\n<input type=\"hidden\" name=\"cmd\" value=\"_s-xclick\">\n<input type=\"hidden\" name=\"hosted_button_id\" value=\"8299526\">\n<input type=\"image\" src=\"https://www.paypal.com/en_GB/i/btn/btn_cart_LG.gif\" border=\"0\" name=\"submit\" alt=\"PayPal - The safer, easier way to pay online.\">\n<img alt=\"\" border=\"0\" src=\"https://www.paypal.com/en_GB/i/scr/pixel.gif\" width=\"1\" height=\"1\">\n</form>\n','2016-11-05 01:21:20'),(2,2,'paypal_button','Long Text','<form target=\"paypal\" action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\">\n<input type=\"hidden\" name=\"cmd\" value=\"_s-xclick\">\n<input type=\"hidden\" name=\"hosted_button_id\" value=\"8299566\">\n<input type=\"image\" src=\"https://www.paypal.com/en_GB/i/btn/btn_cart_LG.gif\" border=\"0\" name=\"submit\" alt=\"PayPal - The safer, easier way to pay online.\">\n<img alt=\"\" border=\"0\" src=\"https://www.paypal.com/en_GB/i/scr/pixel.gif\" width=\"1\" height=\"1\">\n</form>\n','2016-11-05 01:21:20'),(3,4,'sizes','Short Text','Small,Medium,Large','2016-11-05 01:21:21'),(4,4,'colours','Short Text','Black,Blacker,Blackest','2016-11-05 01:21:21');
/*!40000 ALTER TABLE `shop_item_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_item_like`
--

DROP TABLE IF EXISTS `shop_item_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_item_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `ip_address` varchar(15) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `shop_item_like_idx_item` (`item`),
  KEY `shop_item_like_idx_user` (`user`),
  CONSTRAINT `shop_item_like_fk_item` FOREIGN KEY (`item`) REFERENCES `shop_item` (`id`),
  CONSTRAINT `shop_item_like_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_item_like`
--

LOCK TABLES `shop_item_like` WRITE;
/*!40000 ALTER TABLE `shop_item_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_item_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_item_postage_option`
--

DROP TABLE IF EXISTS `shop_item_postage_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_item_postage_option` (
  `item` int(11) NOT NULL,
  `postage` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`item`,`postage`),
  KEY `shop_item_postage_option_idx_item` (`item`),
  KEY `shop_item_postage_option_idx_postage` (`postage`),
  CONSTRAINT `shop_item_postage_option_fk_item` FOREIGN KEY (`item`) REFERENCES `shop_item` (`id`),
  CONSTRAINT `shop_item_postage_option_fk_postage` FOREIGN KEY (`postage`) REFERENCES `postage_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_item_postage_option`
--

LOCK TABLES `shop_item_postage_option` WRITE;
/*!40000 ALTER TABLE `shop_item_postage_option` DISABLE KEYS */;
INSERT INTO `shop_item_postage_option` VALUES (1,1,'2016-11-05 01:21:20'),(1,2,'2016-11-05 01:21:20'),(1,3,'2016-11-05 01:21:20'),(2,1,'2016-11-05 01:21:20'),(2,2,'2016-11-05 01:21:20'),(2,3,'2016-11-05 01:21:20'),(3,1,'2016-11-05 01:21:20'),(3,2,'2016-11-05 01:21:20'),(3,3,'2016-11-05 01:21:20'),(4,2,'2016-11-05 01:21:21'),(4,3,'2016-11-05 01:21:21');
/*!40000 ALTER TABLE `shop_item_postage_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_product_type`
--

DROP TABLE IF EXISTS `shop_product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_product_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `template_file` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_product_type`
--

LOCK TABLES `shop_product_type` WRITE;
/*!40000 ALTER TABLE `shop_product_type` DISABLE KEYS */;
INSERT INTO `shop_product_type` VALUES (1,'Standard','standard.tt','2016-11-05 01:21:20'),(2,'Paypal','paypal.tt','2016-11-05 01:21:20'),(3,'T-shirt','t-shirt.tt','2016-11-05 01:21:20');
/*!40000 ALTER TABLE `shop_product_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_product_type_element`
--

DROP TABLE IF EXISTS `shop_product_type_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_product_type_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Short Text',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `shop_product_type_element_idx_product_type` (`product_type`),
  CONSTRAINT `shop_product_type_element_fk_product_type` FOREIGN KEY (`product_type`) REFERENCES `shop_product_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_product_type_element`
--

LOCK TABLES `shop_product_type_element` WRITE;
/*!40000 ALTER TABLE `shop_product_type_element` DISABLE KEYS */;
INSERT INTO `shop_product_type_element` VALUES (1,2,'paypal_button','Long Text','2016-11-05 01:21:20'),(2,3,'sizes','Short Text','2016-11-05 01:21:20'),(3,3,'colours','Short Text','2016-11-05 01:21:20');
/*!40000 ALTER TABLE `shop_product_type_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription`
--

DROP TABLE IF EXISTS `subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list` int(11) NOT NULL,
  `recipient` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `subscription_idx_list` (`list`),
  KEY `subscription_idx_recipient` (`recipient`),
  CONSTRAINT `subscription_fk_list` FOREIGN KEY (`list`) REFERENCES `mailing_list` (`id`),
  CONSTRAINT `subscription_fk_recipient` FOREIGN KEY (`recipient`) REFERENCES `mail_recipient` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription`
--

LOCK TABLES `subscription` WRITE;
/*!40000 ALTER TABLE `subscription` DISABLE KEYS */;
INSERT INTO `subscription` VALUES (1,1,1,'2016-11-05 01:21:41'),(2,1,2,'2016-11-05 01:21:41'),(3,1,3,'2016-11-05 01:21:41'),(4,2,4,'2016-11-05 01:21:41');
/*!40000 ALTER TABLE `subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tag` varchar(50) NOT NULL,
  `tagset` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tag`,`tagset`),
  KEY `tag_idx_tagset` (`tagset`),
  CONSTRAINT `tag_fk_tagset` FOREIGN KEY (`tagset`) REFERENCES `tagset` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES ('test',14,'2016-11-05 01:20:51');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagset`
--

DROP TABLE IF EXISTS `tagset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `resource_type` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagset`
--

LOCK TABLES `tagset` WRITE;
/*!40000 ALTER TABLE `tagset` DISABLE KEYS */;
INSERT INTO `tagset` VALUES (14,1,'ForumPost','2016-11-05 01:20:51');
/*!40000 ALTER TABLE `tagset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_log`
--

DROP TABLE IF EXISTS `transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL,
  `notes` text,
  `user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_log_idx_user` (`user`),
  CONSTRAINT `transaction_log_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_log`
--

LOCK TABLES `transaction_log` WRITE;
/*!40000 ALTER TABLE `transaction_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_access`
--

DROP TABLE IF EXISTS `user_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_access` (
  `user` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `subscription_id` varchar(50) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `recurring` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user`,`access`),
  KEY `user_access_idx_access` (`access`),
  KEY `user_access_idx_user` (`user`),
  CONSTRAINT `user_access_fk_access` FOREIGN KEY (`access`) REFERENCES `access` (`id`),
  CONSTRAINT `user_access_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_access`
--

LOCK TABLES `user_access` WRITE;
/*!40000 ALTER TABLE `user_access` DISABLE KEYS */;
INSERT INTO `user_access` VALUES (1,1,NULL,NULL,NULL,'2016-11-05 01:19:24');
/*!40000 ALTER TABLE `user_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_ip_address`
--

DROP TABLE IF EXISTS `user_ip_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ip_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_ip_address_idx_user` (`user`),
  CONSTRAINT `user_ip_address_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ip_address`
--

LOCK TABLES `user_ip_address` WRITE;
/*!40000 ALTER TABLE `user_ip_address` DISABLE KEYS */;
INSERT INTO `user_ip_address` VALUES (2,1,'107.217.160.207','2016-11-05 02:08:29'),(3,1,'107.217.160.207','2016-11-05 02:12:08'),(4,1,'107.217.160.207','2016-11-05 06:58:07'),(5,1,'192.168.1.4','2016-11-09 19:00:16'),(6,4,'192.168.1.4','2016-11-09 19:15:48');
/*!40000 ALTER TABLE `user_ip_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user`,`role`),
  KEY `user_role_idx_role` (`role`),
  KEY `user_role_idx_user` (`user`),
  CONSTRAINT `user_role_fk_role` FOREIGN KEY (`role`) REFERENCES `role` (`id`),
  CONSTRAINT `user_role_fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,1,'2016-11-05 01:18:19'),(1,2,'2016-11-05 01:18:19'),(1,3,'2016-11-05 01:18:19'),(1,4,'2016-11-05 01:18:19'),(1,5,'2016-11-05 01:18:19'),(1,6,'2016-11-05 01:18:20'),(1,7,'2016-11-05 01:18:20'),(1,8,'2016-11-05 01:18:20'),(1,9,'2016-11-05 01:18:20'),(1,10,'2016-11-05 01:18:20'),(1,11,'2016-11-05 01:18:20'),(1,12,'2016-11-05 01:18:20'),(1,13,'2016-11-05 01:18:20'),(1,14,'2016-11-05 01:18:20'),(1,15,'2016-11-05 01:18:20'),(1,16,'2016-11-05 01:18:20'),(1,17,'2016-11-05 01:18:20'),(2,7,'2016-11-05 01:19:46'),(3,8,'2016-11-05 01:20:20'),(4,1,'2016-11-09 19:23:49'),(4,6,'2016-11-09 19:23:49');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-10  9:37:23
